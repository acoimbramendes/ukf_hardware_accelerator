#ifndef UKFCFG_H
#define UKFCFG_H

#include "ukfLib.h"

extern tUkfMatrix UkfMatrixCfg0;

#endif /* UKFCFG_H */

