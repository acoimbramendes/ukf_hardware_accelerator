#ifndef UKFCFG1_H
#define UKFCFG1_H

#include "ukfLib.h"

extern tUkfMatrix UkfMatrixCfg1;

#endif /* UKFCFG1_H */

