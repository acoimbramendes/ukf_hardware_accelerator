/* 
 * File: _coder_Cholesky_info.h 
 *  
 * MATLAB Coder version            : 3.1 
 * C/C++ source code generated on  : 07-Nov-2018 18:08:12 
 */

#ifndef _CODER_CHOLESKY_INFO_H
#define _CODER_CHOLESKY_INFO_H
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#endif
/* 
 * File trailer for _coder_Cholesky_info.h 
 *  
 * [EOF] 
 */
