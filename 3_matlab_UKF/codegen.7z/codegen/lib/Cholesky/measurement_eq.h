/*
 * File: measurement_eq.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 27-Oct-2018 21:12:24
 */

#ifndef MEASUREMENT_EQ_H
#define MEASUREMENT_EQ_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "Cholesky_types.h"

/* Function Declarations */
extern double measurement_eq(const double x[3]);

#endif

/*
 * File trailer for measurement_eq.h
 *
 * [EOF]
 */
